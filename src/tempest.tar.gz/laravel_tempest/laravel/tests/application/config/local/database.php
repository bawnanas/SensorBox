<?php

return array(

	'default' => 'sqlite',


	//added from http://forums.laravel.io/viewtopic.php?id=2521
	// to use an in-memory database
	// 'connections' => array(

	// 	'sqlite' => array(
	// 		'driver'   => 'sqlite',
	// 		'database' => ':memory:', // this will do the trick ;)
	// 		'prefix'   => '',
	// 	),

);